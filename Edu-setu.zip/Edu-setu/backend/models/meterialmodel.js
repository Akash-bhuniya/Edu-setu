const db = require('./db');

async function addMaterial(teacherId, title, description, fileUrl) {
  const [result] = await db.query(
    `INSERT INTO materials (teacher_id, title, description, file_url) VALUES (?, ?, ?, ?)`,
    [teacherId, title, description, fileUrl]
  );
  return result.insertId;
}

async function getAllMaterials() {
  const [rows] = await db.query(`SELECT m.*, u.name AS teacher_name 
    FROM materials m JOIN users u ON m.teacher_id = u.id ORDER BY m.created_at DESC`);
  return rows;
}

module.exports = { addMaterial, getAllMaterials };
