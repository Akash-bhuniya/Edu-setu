require('dotenv').config();
const express = require('express');
const path = require('path');

const authRoutes = require('../routes/authRoutes');
const materialRoutes = require('./routes/materialRoutes');

const app = express();
app.use(express.json());

// serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/auth', authRoutes);
app.use('/api/materials', materialRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
