const path = require('path');
const { addMaterial, getAllMaterials } = require('../models/materialModel');

async function uploadMaterial(req, res) {
  const { title, description } = req.body;
  const file = req.file;
  if (!file || !title) return res.status(400).send('Missing data');
  const fileUrl = `/uploads/${file.filename}`;
  const id = await addMaterial(req.user.id, title, description, fileUrl);
  res.json({ message: 'Uploaded', id, fileUrl });
}

async function listMaterials(req, res) {
  const materials = await getAllMaterials();
  res.json(materials);
}

module.exports = { uploadMaterial, listMaterials };
