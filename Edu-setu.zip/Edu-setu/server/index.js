const express = require('express');
const app = express(); // ✅ app created before use

app.use(express.json()); // ✅ now this is safe
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

const authRoutes = require('./auth');
app.use('/', authRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
