// server/db.js
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',       // 👉 your MySQL username
  password: 'akash@123',       // 👉 your MySQL password
  database: 'secure_login' // 👉 your database name (make sure it's created in MySQL)
});

db.connect((err) => {
  if (err) {
    console.error('❌ MySQL connection failed:', err);
  } else {
    console.log('✅ Connected to MySQL database');
  }
});

module.exports = db;
